/**
 * Fortis EasyChat incremental sync.
 * Secrets are stored in Script Properties, not in sheet cells.
 * Required Script Properties:
 * CHAT_SYNC_URL  e.g. https://fortis-easychat-sync.onrender.com
 * CHAT_SYNC_KEY  same SYNC_KEY configured in Render
 * Optional:
 * CHAT_SYNC_SINCE unix seconds; defaults to now-2h on first run
 * CHAT_SYNC_RECENT_KEYS JSON array used to dedupe the overlap window
 */

function syncFortisChats() {
  const props = PropertiesService.getScriptProperties();
  const baseUrl = (props.getProperty('CHAT_SYNC_URL') || '').replace(/\/$/, '');
  const syncKey = props.getProperty('CHAT_SYNC_KEY') || '';
  if (!baseUrl || !syncKey) throw new Error('Set CHAT_SYNC_URL and CHAT_SYNC_KEY in Script Properties.');

  const nowSec = Math.floor(Date.now() / 1000);
  const since = Number(props.getProperty('CHAT_SYNC_SINCE') || (nowSec - 7200));
  const url = baseUrl + '/sync?since=' + encodeURIComponent(String(since)) + '&overlap_seconds=120';

  const response = UrlFetchApp.fetch(url, {
    method: 'get',
    headers: { 'X-Sync-Key': syncKey },
    muteHttpExceptions: true,
    followRedirects: true
  });

  const code = response.getResponseCode();
  const body = response.getContentText();
  if (code !== 200) throw new Error('Chat sync HTTP ' + code + ': ' + body.slice(0, 500));

  const payload = JSON.parse(body);
  if (!payload || !Array.isArray(payload.messages)) throw new Error('Invalid chat sync payload.');

  const recentKeys = new Set(JSON.parse(props.getProperty('CHAT_SYNC_RECENT_KEYS') || '[]'));
  const newKeys = [];
  const linked = [];
  const unlinked = [];

  payload.messages.forEach(function(m) {
    const key = String(m.dialogue_id) + ':' + String(m.message_id);
    if (recentKeys.has(key)) return;
    recentKeys.add(key);
    newKeys.push(key);

    const row = [
      m.client_id == null ? '' : Number(m.client_id),
      m.dialogue_name || '',
      m.created_at_iso ? new Date(m.created_at_iso) : '',
      m.direction || '',
      m.text || '',
      m.channel_id == null ? '' : m.channel_id,
      m.dialogue_id == null ? '' : m.dialogue_id,
      m.message_id == null ? '' : m.message_id,
      m.operator_id == null ? '' : m.operator_id,
      m.crm_manager_id == null ? '' : m.crm_manager_id,
      m.integration_chat_id == null ? '' : String(m.integration_chat_id),
      m.message_type == null ? '' : m.message_type
    ];

    if (m.client_id == null || m.client_id === '') unlinked.push(row);
    else linked.push(row);
  });

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  appendChatRows_(ss.getSheetByName('Чаты_API'), linked);
  appendChatRows_(ss.getSheetByName('Чаты_непривязанные'), unlinked);

  // Keep only a bounded ring of recently seen keys; enough to cover multiple overlap windows.
  const combined = JSON.parse(props.getProperty('CHAT_SYNC_RECENT_KEYS') || '[]').concat(newKeys);
  const deduped = Array.from(new Set(combined));
  const keep = deduped.slice(Math.max(0, deduped.length - 5000));
  props.setProperty('CHAT_SYNC_RECENT_KEYS', JSON.stringify(keep));
  props.setProperty('CHAT_SYNC_SINCE', String(payload.next_since || nowSec));
  props.setProperty('CHAT_SYNC_LAST_OK', new Date().toISOString());
  props.setProperty('CHAT_SYNC_LAST_COUNTS', JSON.stringify({
    linked: linked.length,
    unlinked: unlinked.length,
    dialogues_changed: payload.dialogues_changed || 0,
    errors: (payload.errors || []).length
  }));

  console.log('Chat sync done. Linked=' + linked.length + ', unlinked=' + unlinked.length + ', changed dialogues=' + (payload.dialogues_changed || 0));
}

function appendChatRows_(sheet, rows) {
  if (!sheet) throw new Error('Chat sheet not found.');
  if (!rows.length) return;
  const startRow = sheet.getLastRow() + 1;
  sheet.getRange(startRow, 1, rows.length, 12).setValues(rows);
  sheet.getRange(startRow, 3, rows.length, 1).setNumberFormat('yyyy-mm-dd hh:mm:ss');
  sheet.getRange(startRow, 5, rows.length, 1).setWrap(true).setVerticalAlignment('top');
}

function setupFortisChatHourlyTrigger() {
  ScriptApp.getProjectTriggers()
    .filter(function(t) { return t.getHandlerFunction() === 'syncFortisChats'; })
    .forEach(function(t) { ScriptApp.deleteTrigger(t); });

  ScriptApp.newTrigger('syncFortisChats')
    .timeBased()
    .everyHours(1)
    .create();

  console.log('Hourly chat sync trigger created.');
}

function testFortisChatService() {
  const props = PropertiesService.getScriptProperties();
  const baseUrl = (props.getProperty('CHAT_SYNC_URL') || '').replace(/\/$/, '');
  const syncKey = props.getProperty('CHAT_SYNC_KEY') || '';
  const response = UrlFetchApp.fetch(baseUrl + '/auth-check', {
    method: 'get',
    headers: { 'X-Sync-Key': syncKey },
    muteHttpExceptions: true
  });
  console.log(response.getResponseCode());
  console.log(response.getContentText());
}
